package com.example.taskmanager;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddTaskActivity extends AppCompatActivity {

    EditText etTitle, etDesc, etDueDate;
    RadioGroup rgPriority;
    RadioButton rbLow, rbMedium, rbHigh;
    Button btnSave, btnCancel;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        etTitle = findViewById(R.id.etTitle);
        etDesc = findViewById(R.id.etDesc);
        etDueDate = findViewById(R.id.etDueDate);
        rgPriority = findViewById(R.id.rgPriority);
        rbLow = findViewById(R.id.rbLow);
        rbMedium = findViewById(R.id.rbMedium);
        rbHigh = findViewById(R.id.rbHigh);
        btnSave = findViewById(R.id.btnSave);
        btnCancel = findViewById(R.id.btnCancel);
        db = new DBHelper(this);

        // Set default priority
        rbMedium.setChecked(true);

        // Set hint with date format examples
        etDueDate.setHint("e.g., 2025-12-15 or 15/12/2025");

        btnSave.setOnClickListener(v -> {
            String title = etTitle.getText().toString().trim();
            String desc = etDesc.getText().toString().trim();
            String dueDate = etDueDate.getText().toString().trim();

            String priority = "Medium";
            int selectedId = rgPriority.getCheckedRadioButtonId();
            if (selectedId == R.id.rbLow) priority = "Low";
            else if (selectedId == R.id.rbHigh) priority = "High";

            if (title.isEmpty()) {
                Toast.makeText(this, "❌ Please enter task title", Toast.LENGTH_SHORT).show();
                return;
            }

            // DBHelper will auto-check if date is expired
            boolean ok = db.insertTask(title, desc, dueDate, priority, "Pending");

            if (ok) {
                // Check if it was auto-completed
                if (db.isDateExpired(dueDate)) {
                    Toast.makeText(this, "✅ Task Added (Auto-completed - Date expired)", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, "✅ Task Added Successfully!", Toast.LENGTH_SHORT).show();
                }
                finish();
            } else {
                Toast.makeText(this, "❌ Failed to add task", Toast.LENGTH_SHORT).show();
            }
        });

        btnCancel.setOnClickListener(v -> finish());
    }
}
