package com.example.taskmanager;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.ArrayList;

public class TaskAdapter extends ArrayAdapter<Task> {

    private Context context;
    private ArrayList<Task> tasks;
    private OnTaskOptionsClickListener optionsClickListener;

    public interface OnTaskOptionsClickListener {
        void onDeleteClick(int position);
        void onUpdateClick(int position);
    }

    public void setOnTaskOptionsClickListener(OnTaskOptionsClickListener listener) {
        this.optionsClickListener = listener;
    }

    public TaskAdapter(Context context, ArrayList<Task> tasks) {
        super(context, 0, tasks);
        this.context = context;
        this.tasks = tasks;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItem = convertView;
        if (listItem == null) {
            listItem = LayoutInflater.from(context).inflate(R.layout.task_item, parent, false);
        }

        Task currentTask = tasks.get(position);

        // Initialize views
        TextView tvTitle = listItem.findViewById(R.id.tvTaskTitle);
        TextView tvDueDate = listItem.findViewById(R.id.tvDueDate);
        TextView tvPriority = listItem.findViewById(R.id.tvPriority);
        TextView tvStatus = listItem.findViewById(R.id.tvStatus);
        TextView tvOptions = listItem.findViewById(R.id.tvOptions);

        // Set task data
        tvTitle.setText(currentTask.getTitle());
        tvDueDate.setText("📅 Due: " + (currentTask.getDueDate().isEmpty() ? "Not set" : currentTask.getDueDate()));
        tvPriority.setText(currentTask.getPriority());
        tvStatus.setText(currentTask.getStatus());

        // Check if task is expired
        boolean isExpired = isTaskExpired(currentTask);

        // Set priority color and background
        switch (currentTask.getPriority()) {
            case "High":
                tvPriority.setTextColor(Color.RED);
                tvPriority.setBackgroundColor(Color.parseColor("#FFEBEE"));
                break;
            case "Medium":
                tvPriority.setTextColor(Color.parseColor("#FF9800"));
                tvPriority.setBackgroundColor(Color.parseColor("#FFF3E0"));
                break;
            case "Low":
                tvPriority.setTextColor(Color.parseColor("#4CAF50"));
                tvPriority.setBackgroundColor(Color.parseColor("#E8F5E8"));
                break;
        }

        // Set status color and style
        if (currentTask.getStatus().equals("Completed")) {
            tvStatus.setText("✅ COMPLETED");
            tvStatus.setTextColor(Color.parseColor("#4CAF50"));
            tvStatus.setBackgroundColor(Color.parseColor("#E8F5E8"));
            tvTitle.setAlpha(0.6f);
            tvTitle.setPaintFlags(tvTitle.getPaintFlags() | android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);

            // For expired tasks that are completed
            if (isExpired) {
                tvDueDate.setText("⌛ Expired: " + currentTask.getDueDate());
                tvDueDate.setTextColor(Color.RED);
            }
        } else {
            // For pending tasks
            if (isExpired) {
                tvStatus.setText("⚠️ EXPIRED");
                tvStatus.setTextColor(Color.WHITE);
                tvStatus.setBackgroundColor(Color.RED);
                tvDueDate.setTextColor(Color.RED);
                tvTitle.setTextColor(Color.RED);
            } else {
                tvStatus.setText("⏳ PENDING");
                tvStatus.setTextColor(Color.parseColor("#FF9800"));
                tvStatus.setBackgroundColor(Color.parseColor("#FFF3E0"));
                tvTitle.setAlpha(1.0f);
                tvTitle.setPaintFlags(tvTitle.getPaintFlags() & (~android.graphics.Paint.STRIKE_THRU_TEXT_FLAG));
            }
        }

        // Options click listener
        tvOptions.setOnClickListener(v -> {
            if (optionsClickListener != null) {
                showOptionsDialog(position);
            }
        });

        return listItem;
    }

    // Show options dialog (Delete/Update)
    private void showOptionsDialog(int position) {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(context);
        builder.setTitle("Task Options")
                .setItems(new String[]{"🗑️ Delete Task", "✏️ Update Task"}, (dialog, which) -> {
                    if (which == 0) {
                        // Delete
                        optionsClickListener.onDeleteClick(position);
                    } else if (which == 1) {
                        // Update
                        optionsClickListener.onUpdateClick(position);
                    }
                })
                .show();
    }

    // Helper method to check if task is expired
    private boolean isTaskExpired(Task task) {
        if (task.getDueDate() == null || task.getDueDate().isEmpty()) {
            return false;
        }

        String dueDate = task.getDueDate().toLowerCase();

        // Check for expired keywords
        return dueDate.contains("yesterday") ||
                dueDate.contains("past") ||
                dueDate.contains("expired") ||
                dueDate.contains("overdue") ||
                dueDate.contains("last") ||
                dueDate.contains("ago");
    }
}
