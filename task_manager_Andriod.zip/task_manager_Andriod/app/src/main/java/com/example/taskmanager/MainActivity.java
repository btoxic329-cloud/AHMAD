package com.example.taskmanager;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements TaskAdapter.OnTaskOptionsClickListener {

    private ListView listView;
    private Button btnAdd, btnViewStats, btnShowCompleted;
    private TextView tvPendingCount, tvDate, tvCompletedCount, tvListHeader;
    private DBHelper db;
    private ArrayList<Task> tasks;
    private TaskAdapter adapter;

    private boolean showCompletedTasks = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        listView = findViewById(R.id.listView);
        btnAdd = findViewById(R.id.btnAdd);
        btnViewStats = findViewById(R.id.btnViewStats);
        btnShowCompleted = findViewById(R.id.btnShowCompleted);
        tvPendingCount = findViewById(R.id.tvPendingCount);
        tvDate = findViewById(R.id.tvDate);
        tvCompletedCount = findViewById(R.id.tvCompletedCount);
        tvListHeader = findViewById(R.id.tvListHeader);

        db = new DBHelper(this);

        // Set current date
        String currentDate = new SimpleDateFormat("EEE, dd MMM yyyy", Locale.getDefault()).format(new Date());
        tvDate.setText("📅 Today: " + currentDate);

        // Automatically update expired tasks
        db.autoUpdateExpiredTasks();

        // Load initial tasks
        loadTasks();

        // Add Task Button
        btnAdd.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, AddTaskActivity.class));
        });

        // View Stats Button
        btnViewStats.setOnClickListener(v -> {
            // Get counts directly from database
            int total = db.getTotalTaskCount();
            int pending = db.getPendingTaskCount();
            int completed = db.getCompletedTaskCount();
            int expiredPending = db.getExpiredPendingTasksCount();

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("📊 Task Statistics")
                    .setMessage("📈 ----Task Statistics Overview----📈\n\n" +

                            "📋 Total Tasks: " + total + "\n\n" +

                            "⏳ Pending Tasks: " + pending + "\n" +
//                            "   ↳ Normal: " + (pending - expiredPending) + "\n" +
//                            "   ↳ ⚠️ Overdue: " + expiredPending + "\n\n" +

                            "✅ Completed Tasks:" + completed + "\n\n" +

                            "📊 Progress: \n" +
                            getProgressBar(completed, total) + "\n" +
                            "   " + getPercentage(completed, total) + "% completed\n\n" +

                            "📅 Today: " + currentDate)
                    .setPositiveButton("✅ OK", null)
                    .setNegativeButton("🔄 Refresh", (dialog, which) -> {
                        // Refresh stats
                        Toast.makeText(MainActivity.this, "✅ Stats refreshed!", Toast.LENGTH_SHORT).show();
                        loadTasks();
                    })
                    .show();
        });

        // Show Completed Tasks Button
        btnShowCompleted.setOnClickListener(v -> {
            showCompletedTasks = !showCompletedTasks;
            if (showCompletedTasks) {
                btnShowCompleted.setText("📝 Show Pending");
                loadCompletedTasks();
            } else {
                btnShowCompleted.setText("✅ Show Completed");
                loadTasks();
            }
        });

        // List item click listener for status toggle
        listView.setOnItemClickListener((parent, view, position, id) -> {
            Task selectedTask = tasks.get(position);
            toggleTaskStatus(selectedTask);
        });
    }

    // Load pending tasks
    private void loadTasks() {
        tasks = db.getPendingTasks();
        adapter = new TaskAdapter(this, tasks);
        adapter.setOnTaskOptionsClickListener(this);
        listView.setAdapter(adapter);

        updateCounters();
    }

    // Load completed tasks
    private void loadCompletedTasks() {
        tasks = db.getCompletedTasks();
        adapter = new TaskAdapter(this, tasks);
        adapter.setOnTaskOptionsClickListener(this);
        listView.setAdapter(adapter);

        updateCounters();
    }

    // Update counters at top
    private void updateCounters() {
        // Get counts directly from database
        int pendingCount = db.getPendingTaskCount();
        int completedCount = db.getCompletedTaskCount();

        tvPendingCount.setText("⏳ Pending: " + pendingCount);
        tvCompletedCount.setText("✅ Completed: " + completedCount);

        // Update list header based on current view
        if (showCompletedTasks) {
            tvListHeader.setText("✅ Completed Tasks (" + completedCount + ")");
        } else {
            tvListHeader.setText("📝 Pending Tasks (" + pendingCount + ")");
        }
    }

    // Helper method for progress bar
    private String getProgressBar(int completed, int total) {
        if (total == 0) return "[░░░░░░░░░░] 0%";

        int percentage = (completed * 100) / total;
        int bars = percentage / 10;

        StringBuilder progressBar = new StringBuilder("[");
        for (int i = 0; i < 10; i++) {
            if (i < bars) {
                progressBar.append("█");
            } else {
                progressBar.append("░");
            }
        }
        progressBar.append("]");

        return progressBar.toString();
    }

    // Helper method for percentage
    private int getPercentage(int completed, int total) {
        if (total == 0) return 0;
        return (completed * 100) / total;
    }

    // Toggle task status
    private void toggleTaskStatus(Task task) {
        String newStatus = task.getStatus().equals("Pending") ? "Completed" : "Pending";
        db.updateTaskStatus(task.getId(), newStatus);
        Toast.makeText(this, "✅ Task marked as " + newStatus, Toast.LENGTH_SHORT).show();

        // Reload appropriate list
        if (showCompletedTasks) {
            loadCompletedTasks();
        } else {
            loadTasks();
        }
    }

    // Delete task (from options dialog)
    @Override
    public void onDeleteClick(int position) {
        Task taskToDelete = tasks.get(position);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("🗑️ Delete Task")
                .setMessage("Are you sure you want to delete this task?\n\n" +
                        "📝 **Task:** " + taskToDelete.getTitle() + "\n" +
                        "📅 **Due Date:** " + taskToDelete.getDueDate())
                .setPositiveButton("✅ Delete", (dialog, which) -> {
                    boolean deleted = db.deleteTask(taskToDelete.getId());
                    if (deleted) {
                        Toast.makeText(this, "✅ Task deleted successfully", Toast.LENGTH_SHORT).show();
                        if (showCompletedTasks) {
                            loadCompletedTasks();
                        } else {
                            loadTasks();
                        }
                    } else {
                        Toast.makeText(this, "❌ Failed to delete task", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("❌ Cancel", null)
                .show();
    }

    // Update task (from options dialog)
    @Override
    public void onUpdateClick(int position) {
        Task taskToUpdate = tasks.get(position);

        // Open UpdateTaskActivity with task details
        Intent intent = new Intent(MainActivity.this, UpdateTaskActivity.class);
        intent.putExtra("task_id", taskToUpdate.getId());
        intent.putExtra("task_title", taskToUpdate.getTitle());
        intent.putExtra("task_desc", taskToUpdate.getDescription());
        intent.putExtra("task_due_date", taskToUpdate.getDueDate());
        intent.putExtra("task_priority", taskToUpdate.getPriority());
        intent.putExtra("task_status", taskToUpdate.getStatus());
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Auto-update expired tasks
        db.autoUpdateExpiredTasks();

        // Reload appropriate list
        if (showCompletedTasks) {
            loadCompletedTasks();
        } else {
            loadTasks();
        }

        // Show notification if tasks were auto-completed
        showAutoCompleteNotification();
    }

    // New method to show auto-complete notification
    private void showAutoCompleteNotification() {
        // Check if any tasks were auto-completed
        // You can implement this if needed
        // For now, we'll just refresh the counters
        updateCounters();

        // Optional: Show a toast if tasks were auto-completed
        // This is just an example - you can customize it
        int totalPending = db.getPendingTaskCount();
        int totalCompleted = db.getCompletedTaskCount();

        if (tasks != null) {
            for (Task task : tasks) {
                if (db.isDateExpired(task.getDueDate()) && task.getStatus().equals("Pending")) {
                    Toast.makeText(this,
                            "⚠️ Some tasks were auto-completed due to expired dates!",
                            Toast.LENGTH_SHORT).show();
                    break;
                }
            }
        }
    }
}
