package com.example.taskmanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "student_tasks.db";
    private static final int DATABASE_VERSION = 3; // Version increase

    // Table and column names
    public static final String TABLE_TASKS = "tasks";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_TITLE = "title";
    public static final String COLUMN_DESCRIPTION = "description";
    public static final String COLUMN_DUE_DATE = "due_date";
    public static final String COLUMN_PRIORITY = "priority";
    public static final String COLUMN_STATUS = "status";
    public static final String COLUMN_CREATED_AT = "created_at";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TASKS_TABLE = "CREATE TABLE " + TABLE_TASKS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_TITLE + " TEXT NOT NULL,"
                + COLUMN_DESCRIPTION + " TEXT,"
                + COLUMN_DUE_DATE + " TEXT,"
                + COLUMN_PRIORITY + " TEXT DEFAULT 'Medium',"
                + COLUMN_STATUS + " TEXT DEFAULT 'Pending',"
                + COLUMN_CREATED_AT + " DATETIME DEFAULT CURRENT_TIMESTAMP"
                + ")";
        db.execSQL(CREATE_TASKS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TASKS);
        onCreate(db);
    }

    // Insert new task with date check
    public boolean insertTask(String title, String desc, String dueDate, String priority, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_TITLE, title);
        cv.put(COLUMN_DESCRIPTION, desc);
        cv.put(COLUMN_DUE_DATE, dueDate);
        cv.put(COLUMN_PRIORITY, priority);

        // Check if date is expired and auto-complete
        if (isDateExpired(dueDate)) {
            cv.put(COLUMN_STATUS, "Completed");
        } else {
            cv.put(COLUMN_STATUS, status);
        }

        long res = db.insert(TABLE_TASKS, null, cv);
        return res != -1;
    }

    // Check if date string is expired
    public boolean isDateExpired(String dateString) {
        if (dateString == null || dateString.isEmpty()) {
            return false;
        }

        // Check for expired keywords
        String lowerDate = dateString.toLowerCase();
        if (lowerDate.contains("yesterday") ||
                lowerDate.contains("past") ||
                lowerDate.contains("expired") ||
                lowerDate.contains("overdue") ||
                lowerDate.contains("last") ||
                lowerDate.contains("ago")) {
            return true;
        }

        // Try to parse as date and compare with today
        try {
            SimpleDateFormat sdf;
            Date dueDate;

            // Try different date formats
            if (dateString.matches("\\d{4}-\\d{2}-\\d{2}")) { // yyyy-MM-dd
                sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                dueDate = sdf.parse(dateString);
            } else if (dateString.matches("\\d{2}/\\d{2}/\\d{4}")) { // dd/MM/yyyy
                sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                dueDate = sdf.parse(dateString);
            } else if (dateString.matches("\\d{2}-\\d{2}-\\d{4}")) { // dd-MM-yyyy
                sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                dueDate = sdf.parse(dateString);
            } else {
                return false; // Can't parse, assume not expired
            }

            // Get today's date (without time)
            Date today = new Date();
            SimpleDateFormat todayFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date todayDate = todayFormat.parse(todayFormat.format(today));

            // Compare dates (remove time part)
            Date dueDateOnly = sdf.parse(sdf.format(dueDate));

            // If due date is before today, it's expired
            return dueDateOnly.before(todayDate);

        } catch (ParseException e) {
            return false; // If can't parse, assume not expired
        }
    }

    // Get pending tasks with auto-expiry check
    public ArrayList<Task> getPendingTasks() {
        ArrayList<Task> taskList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM " + TABLE_TASKS +
                " WHERE " + COLUMN_STATUS + " = 'Pending'" +
                " ORDER BY " +
                "CASE " + COLUMN_PRIORITY + " " +
                "WHEN 'High' THEN 1 " +
                "WHEN 'Medium' THEN 2 " +
                "WHEN 'Low' THEN 3 END, " + COLUMN_DUE_DATE;

        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                Task task = new Task();
                task.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)));
                task.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)));
                task.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION)));
                String dueDate = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DUE_DATE));
                task.setDueDate(dueDate);
                task.setPriority(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PRIORITY)));
                task.setStatus(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STATUS)));

                // Auto-check and update if expired
                if (isDateExpired(dueDate)) {
                    updateTaskStatus(task.getId(), "Completed");
                    task.setStatus("Completed");
                }

                // Only add if still pending after check
                if (task.getStatus().equals("Pending")) {
                    taskList.add(task);
                }

            } while (cursor.moveToNext());
        }
        cursor.close();
        return taskList;
    }

    // Get completed tasks
    public ArrayList<Task> getCompletedTasks() {
        ArrayList<Task> taskList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM " + TABLE_TASKS +
                " WHERE " + COLUMN_STATUS + " = 'Completed'" +
                " ORDER BY " + COLUMN_DUE_DATE + " DESC";

        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                Task task = new Task();
                task.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)));
                task.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)));
                task.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION)));
                task.setDueDate(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DUE_DATE)));
                task.setPriority(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PRIORITY)));
                task.setStatus(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STATUS)));

                taskList.add(task);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return taskList;
    }

    // Update task with date check
    public boolean updateTask(int id, String title, String desc, String dueDate, String priority, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_TITLE, title);
        cv.put(COLUMN_DESCRIPTION, desc);
        cv.put(COLUMN_DUE_DATE, dueDate);
        cv.put(COLUMN_PRIORITY, priority);

        // Check if date is expired and auto-complete
        if (isDateExpired(dueDate)) {
            cv.put(COLUMN_STATUS, "Completed");
        } else {
            cv.put(COLUMN_STATUS, status);
        }

        int rowsAffected = db.update(TABLE_TASKS, cv,
                COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)});
        return rowsAffected > 0;
    }

    // Update task status
    public boolean updateTaskStatus(int id, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_STATUS, status);

        int rowsAffected = db.update(TABLE_TASKS, cv,
                COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)});
        return rowsAffected > 0;
    }

    // Delete task
    public boolean deleteTask(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_TASKS, COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)}) > 0;
    }

    // COUNT METHODS
    public int getTotalTaskCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT COUNT(*) FROM " + TABLE_TASKS;
        Cursor cursor = db.rawQuery(query, null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    public int getPendingTaskCount() {
        SQLiteDatabase db = this.getReadableDatabase();

        // First auto-update expired tasks
        autoUpdateExpiredTasks();

        String query = "SELECT COUNT(*) FROM " + TABLE_TASKS +
                " WHERE " + COLUMN_STATUS + " = 'Pending'";
        Cursor cursor = db.rawQuery(query, null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    public int getCompletedTaskCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT COUNT(*) FROM " + TABLE_TASKS +
                " WHERE " + COLUMN_STATUS + " = 'Completed'";
        Cursor cursor = db.rawQuery(query, null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    public int getExpiredPendingTasksCount() {
        SQLiteDatabase db = this.getReadableDatabase();

        // Check all pending tasks for expiry
        int expiredCount = 0;
        String query = "SELECT * FROM " + TABLE_TASKS +
                " WHERE " + COLUMN_STATUS + " = 'Pending'";

        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                String dueDate = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DUE_DATE));
                if (isDateExpired(dueDate)) {
                    expiredCount++;
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return expiredCount;
    }

    // Auto-update expired tasks
    public void autoUpdateExpiredTasks() {
        SQLiteDatabase db = this.getWritableDatabase();

        // Get all pending tasks
        String selectQuery = "SELECT * FROM " + TABLE_TASKS +
                " WHERE " + COLUMN_STATUS + " = 'Pending'";

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));
                String dueDate = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DUE_DATE));

                // Check if expired
                if (isDateExpired(dueDate)) {
                    // Update to completed
                    ContentValues cv = new ContentValues();
                    cv.put(COLUMN_STATUS, "Completed");
                    db.update(TABLE_TASKS, cv,
                            COLUMN_ID + " = ?",
                            new String[]{String.valueOf(id)});
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
    }
}


