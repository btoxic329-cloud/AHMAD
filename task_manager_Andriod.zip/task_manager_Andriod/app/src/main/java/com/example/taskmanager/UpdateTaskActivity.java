package com.example.taskmanager;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class UpdateTaskActivity extends AppCompatActivity {

    EditText etTitle, etDesc, etDueDate;
    RadioGroup rgPriority;
    RadioButton rbLow, rbMedium, rbHigh;
    Button btnUpdate, btnCancel;
    DBHelper db;

    int taskId;
    String originalTitle, originalDesc, originalDueDate, originalPriority, originalStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_task);

        etTitle = findViewById(R.id.etTitle);
        etDesc = findViewById(R.id.etDesc);
        etDueDate = findViewById(R.id.etDueDate);
        rgPriority = findViewById(R.id.rgPriority);
        rbLow = findViewById(R.id.rbLow);
        rbMedium = findViewById(R.id.rbMedium);
        rbHigh = findViewById(R.id.rbHigh);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnCancel = findViewById(R.id.btnCancel);

        db = new DBHelper(this);

        // Get task data from intent
        taskId = getIntent().getIntExtra("task_id", -1);
        originalTitle = getIntent().getStringExtra("task_title");
        originalDesc = getIntent().getStringExtra("task_desc");
        originalDueDate = getIntent().getStringExtra("task_due_date");
        originalPriority = getIntent().getStringExtra("task_priority");
        originalStatus = getIntent().getStringExtra("task_status");

        // Populate fields with current data
        etTitle.setText(originalTitle);
        etDesc.setText(originalDesc);
        etDueDate.setText(originalDueDate);

        // Set priority radio button
        switch (originalPriority) {
            case "Low":
                rbLow.setChecked(true);
                break;
            case "Medium":
                rbMedium.setChecked(true);
                break;
            case "High":
                rbHigh.setChecked(true);
                break;
        }

        // Set hint with date format
        etDueDate.setHint("e.g., 2025-12-15 or 15/12/2025");

        btnUpdate.setOnClickListener(v -> {
            String title = etTitle.getText().toString().trim();
            String desc = etDesc.getText().toString().trim();
            String dueDate = etDueDate.getText().toString().trim();

            String priority = "Medium";
            int selectedId = rgPriority.getCheckedRadioButtonId();
            if (selectedId == R.id.rbLow) priority = "Low";
            else if (selectedId == R.id.rbHigh) priority = "High";

            if (title.isEmpty()) {
                Toast.makeText(this, "❌ Please enter task title", Toast.LENGTH_SHORT).show();
                return;
            }

            // DBHelper will auto-check if date is expired
            boolean ok = db.updateTask(taskId, title, desc, dueDate, priority, originalStatus);

            if (ok) {
                // Check if it was auto-completed
                if (db.isDateExpired(dueDate)) {
                    Toast.makeText(this, "✅ Task Updated (Auto-completed - Date expired)", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, "✅ Task Updated Successfully!", Toast.LENGTH_SHORT).show();
                }
                finish();
            } else {
                Toast.makeText(this, "❌ Failed to update task", Toast.LENGTH_SHORT).show();
            }
        });

        btnCancel.setOnClickListener(v -> finish());
    }
}